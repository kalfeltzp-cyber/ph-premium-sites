---
name: 3d-web-experience
description: Planeja e implementa experiências 3D para sites usando Three.js ou React Three Fiber quando agregam valor ao produto. Use para hero 3D, visualizadores e cenas interativas.
---

# 3D Web Experience

Use 3D somente quando ajudar a explicar, demonstrar ou valorizar algo. Primeiro confirme o stack e as dependências existentes.

Diretrizes:
- Prefira React Three Fiber/Drei em projetos React já compatíveis; Three.js direto quando fizer mais sentido.
- Faça fallback estático para dispositivos sem WebGL ou com preferência por movimento reduzido.
- Limite polígonos, texturas, luzes, partículas e draw calls.
- Carregue cenas de forma progressiva; não bloqueie conteúdo essencial.
- Implemente resize, limpeza de recursos e descarte de geometrias/texturas.
- Respeite `prefers-reduced-motion`, teclado e controles acessíveis.
- Evite 3D em páginas onde uma imagem otimizada comunica melhor.

Antes de adicionar dependências, apresente a razão e verifique compatibilidade. Teste desempenho em viewport móvel quando possível. Nunca sacrifique a leitura ou a conversão pelo efeito visual.
