---
name: anti-generic-design
description: Revisa e cria interfaces web distintas, evitando padrões visuais genéricos de templates e geradores de IA. Use ao criar ou melhorar páginas e componentes.
---

# Anti-Generic Design

Evite a combinação automática de fundo gradiente, cartões repetidos, cantos exageradamente arredondados, ícones aleatórios, títulos clichês e seções com a mesma composição.

Processo:
1. Observe o segmento, marca, materiais reais, concorrentes e conteúdo disponível.
2. Escolha uma ideia visual central e traduza-a em layout, tipografia, imagem e interação.
3. Varie composição entre seções: editorial, produto, prova, serviço, FAQ e CTA devem ter hierarquia própria.
4. Use imagens autênticas fornecidas pelo cliente sempre que disponíveis; nunca substitua logotipos por texto improvisado.
5. Evite efeitos sem função. Garanta contraste, legibilidade e foco no conteúdo.
6. Compare a página inteira em desktop e mobile para detectar repetição e inconsistência.

Antes de concluir, liste três decisões específicas que tornam a página adequada àquela marca, não a qualquer empresa.
