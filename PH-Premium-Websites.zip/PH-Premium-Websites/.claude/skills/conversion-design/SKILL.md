---
name: conversion-design
description: Estrutura páginas e interfaces para transformar visitantes em contatos e oportunidades comerciais sem práticas enganosas. Use ao criar landing pages, páginas de serviço ou CTAs.
---

# Conversion Design

1. Identifique uma conversão principal mensurável: ligação, WhatsApp, formulário, agendamento ou compra.
2. Coloque proposta de valor clara acima da dobra, sem promessas não comprovadas.
3. Organize a página: problema/necessidade, solução, benefícios verificáveis, processo, evidências reais, objeções e CTA.
4. Use chamadas específicas e consistentes; reduza campos de formulário ao mínimo necessário.
5. Torne contato e preço/condições fáceis de encontrar quando fornecidos.
6. Use prova social somente com autorização e dados verdadeiros.
7. Não crie urgência falsa, contadores falsos, avaliações inventadas ou dark patterns.
8. Meça eventos úteis se a infraestrutura de analytics já existir e houver consentimento apropriado.

Revise se a página responde: o que é oferecido, para quem, por que confiar e qual é o próximo passo.
