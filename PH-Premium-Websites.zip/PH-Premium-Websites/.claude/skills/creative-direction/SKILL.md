---
name: creative-direction
description: Define direção de arte, conceito visual, hierarquia e identidade para sites profissionais. Use ao iniciar um site, reformular uma marca ou escolher uma linguagem visual.
---

# Creative Direction

Atue como diretor de arte digital. Antes de codificar:
1. Identifique segmento, público, objetivo comercial, diferenciais comprovados e ação principal.
2. Proponha um conceito visual específico ao negócio; evite repetir a mesma estética entre clientes.
3. Defina paleta com função semântica, tipografia, grid, ritmo de espaçamento, tratamento de imagens e estilo de componentes.
4. Explique em poucas linhas como as escolhas apoiam confiança, diferenciação e conversão.
5. Se faltarem dados essenciais, faça no máximo uma pergunta objetiva; caso contrário, declare suposições e prossiga.

Não invente história, posicionamento, prêmios, depoimentos ou diferenciais do cliente. Não use estética luxuosa automaticamente: a direção deve combinar com o público e o preço do negócio.
