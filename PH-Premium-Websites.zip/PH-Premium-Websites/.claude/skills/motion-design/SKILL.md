---
name: motion-design
description: Cria animações web intencionais com CSS, GSAP e ScrollTrigger, incluindo microinterações e transições. Use ao adicionar movimento ou refinar interações.
---

# Motion Design

1. Defina o propósito de cada animação: orientar, revelar hierarquia, confirmar ação ou demonstrar produto.
2. Prefira CSS para transições simples; use GSAP quando houver sequência, timeline ou sincronização com scroll.
3. Use easing consistente, duração moderada e movimento natural.
4. Evite animar propriedades que provoquem layout repetido; prefira transform e opacity.
5. Não capture o scroll nem impeça navegação natural.
6. Desative ou simplifique animações com `prefers-reduced-motion`.
7. Garanta que conteúdo essencial apareça mesmo se JavaScript falhar.
8. Limpe timelines e listeners ao desmontar componentes.

Não anime todos os elementos. Preserve estabilidade visual, desempenho móvel e acessibilidade.
