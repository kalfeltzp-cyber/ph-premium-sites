---
name: premium-frontend
description: Implementa sites frontend refinados, responsivos e rápidos, respeitando a arquitetura e as dependências existentes. Use ao desenvolver páginas, componentes ou landing pages.
---

# Premium Frontend

1. Inspecione estrutura, package manager, scripts, framework, rotas, componentes e convenções existentes antes de editar.
2. Preserve o stack. Não reescreva o projeto nem instale bibliotecas sem justificativa.
3. Crie componentes reutilizáveis quando houver repetição real; evite abstrações prematuras.
4. Garanta hierarquia tipográfica, espaçamento consistente, estados hover/focus/active e conteúdo realista.
5. Trate loading, erro, vazio e sucesso quando houver interação ou dados.
6. Otimize imagens, fontes, carregamento e divisão de código.
7. Execute lint, typecheck, testes e build disponíveis.
8. Informe arquivos alterados, decisões importantes e verificações realizadas.

Não diga que algo funciona sem executar ou verificar. Não deixe botões decorativos sem ação.
