---
name: responsive-accessibility
description: Garante responsividade, acessibilidade e usabilidade em sites e componentes. Use ao implementar ou revisar layouts para desktop, tablet e celular.
---

# Responsive Accessibility

- Comece por conteúdo e layout mobile-first; valide larguras pequenas, médias e grandes.
- Evite largura fixa que cause overflow horizontal.
- Use HTML semântico, labels associados, landmarks e ordem de heading lógica.
- Garanta navegação por teclado, foco visível e nomes acessíveis.
- Verifique contraste, tamanho de texto, alvos de toque e zoom.
- Não dependa apenas de cor para transmitir estado.
- Respeite `prefers-reduced-motion`.
- Teste menus, formulários, modais e elementos interativos em teclado e toque.

Registre problemas encontrados e corrija os que forem relevantes para a tarefa.
