---
name: visual-quality-audit
description: Audita qualidade visual, funcional, responsiva, acessibilidade, SEO básico e desempenho de sites antes da entrega.
---

# Visual Quality Audit

Faça auditoria baseada em evidências:
1. Execute o projeto e abra as páginas relevantes quando ferramentas de browser estiverem disponíveis.
2. Verifique desktop e mobile; capture screenshots se possível.
3. Procure overflow, desalinhamento, tipografia inconsistente, imagens quebradas, conteúdo cortado e contraste insuficiente.
4. Teste links, botões, navegação, formulários e estados interativos.
5. Confira títulos, metadescrição, headings, alt text, favicon e links sociais quando aplicável.
6. Execute lint, typecheck, testes e build disponíveis.
7. Identifique recursos pesados e animações que prejudiquem o carregamento.
8. Classifique achados por severidade: bloqueador, alto, médio ou baixo.

Corrija problemas diretamente quando autorizado. Ao final, informe o que foi testado, o que foi corrigido e o que não pôde ser verificado. Nunca invente resultados de teste.
