# PH Premium Websites

Kit de Skills para Claude Code focado em sites premium, identidade visual própria, animações, experiências 3D e conversão.

## Conteúdo

As Skills ficam em `.claude/skills/` e são descobertas pelo Claude Code quando você abre o projeto ou instala as pastas no diretório global.

- `creative-direction`: direção de arte e identidade visual.
- `anti-generic-design`: evita layouts genéricos e aparência de template.
- `premium-frontend`: arquitetura e implementação frontend.
- `3d-web-experience`: Three.js / React Three Fiber / WebGL com propósito.
- `motion-design`: GSAP, ScrollTrigger, microinterações e movimento.
- `conversion-design`: estrutura orientada a contatos e vendas.
- `responsive-accessibility`: responsividade, acessibilidade e usabilidade.
- `visual-quality-audit`: revisão visual, funcional e técnica.

## Instalação no projeto atual

Copie a pasta `.claude/skills/` deste repositório para a raiz do projeto em que você usa Claude Code.

## Instalação global

No macOS/Linux, a partir da raiz deste repositório:

```bash
bash install.sh
```

No Windows PowerShell:

```powershell
.\install.ps1
```

Os instaladores copiam as Skills para `~/.claude/skills/` (Windows: `$HOME\.claude\skills\`).

## Como usar

Reinicie ou abra uma nova sessão do Claude Code. Você pode pedir, por exemplo:

- "Crie uma landing page premium para uma clínica, usando a direção visual adequada ao negócio."
- "Revise esta página para eliminar aparência genérica de template."
- "Adicione uma experiência 3D leve e interativa ao hero, somente se melhorar a apresentação."
- "Faça uma auditoria visual e de conversão da página."

## Princípios

1. Não inventar conteúdo, avaliações, clientes, resultados ou certificações.
2. Não adicionar 3D ou animação só por decoração.
3. Priorizar velocidade, acessibilidade, responsividade e clareza.
4. Não substituir o stack existente sem necessidade.
5. Inspecionar o projeto antes de editar e reutilizar componentes existentes.
6. Testar o que for possível e declarar claramente o que não foi testado.

## Requisitos

Claude Code e um projeto web. Dependências de animação/3D são opcionais e só devem ser adicionadas quando necessárias.
