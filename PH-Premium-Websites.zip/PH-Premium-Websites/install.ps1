$ErrorActionPreference = "Stop"
$SourceDir = Join-Path $PSScriptRoot ".claude\skills"
$TargetDir = Join-Path $HOME ".claude\skills"
New-Item -ItemType Directory -Force -Path $TargetDir | Out-Null
Copy-Item -Path (Join-Path $SourceDir "*") -Destination $TargetDir -Recurse -Force
Write-Host "PH Premium Websites instalado em $TargetDir"
